const http = require('http');
const fs = require('fs');
const path = require('path');
port = 3000;
let server = http.createServer((req,res)=>{
    const {method} = req;
   
    switch(method){
        case "GET":
            res.writeHead(200,{'Content-Type':'text/plain'});
            fs.readFile('newfile.txt',(err,data)=>{
            if(err){
                res.writeHead(404);
                res.writeHead("Some Error Occurres");
            }else{
                res.write(data);
            }
            res.end();
            })
            break;
        case "POST":
            let body = '';
            req.on('data', chunk => {
                body += chunk.toString(); 
            });
            req.on('end', () => {
                fs.writeFile('newfile.txt', body , err => {
                    if (err) {
                        res.writeHead(500, { 'Content-Type': 'text/plain' });
                        res.write('Some Error Occurred');
                    } else {
                        res.writeHead(201, { 'Content-Type': 'text/plain' });
                        res.write('File created successfully');
                    }
                    res.end();
                });
            });
            break;
        
        case "DELETE":
            fs.unlink('newfile.txt',(err)=>{
                if(err){
                    res.writeHead(404,{'Content-Type':'text/plain'});
                    res.write("Some Error Occured");
                }else{
                    res.writeHead(201,{'Content-Type':'Tesxt/plain'});
                    res.write('File Delete Successfully');

                }
                res.end();
            })
            break;



    }
})

server.listen(port,(err)=>{
    if(err){
        console.log("Something went Wrong");
    }
    console.log("Server is listening port " + port);
})